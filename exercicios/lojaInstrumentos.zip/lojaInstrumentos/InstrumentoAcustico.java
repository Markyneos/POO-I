public interface InstrumentoAcustico {

	public void tocarAcustico();
}
