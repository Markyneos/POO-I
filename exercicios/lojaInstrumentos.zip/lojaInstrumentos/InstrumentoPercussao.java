public interface InstrumentoPercussao {

	public void tocar();

}
